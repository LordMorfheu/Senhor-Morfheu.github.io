/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

const ai = new GoogleGenAI({ apiKey: API_KEY });

const form = document.getElementById('url-form') as HTMLFormElement;
const urlInput = document.getElementById('url-input') as HTMLInputElement;
const analyzeButton = document.getElementById('analyze-button') as HTMLButtonElement;
const resultContainer = document.getElementById('result-container') as HTMLElement;

/**
 * Calls the Google Safe Browsing API to check for threats.
 * @param url The URL to check.
 * @returns An object with the status and details of the check.
 */
async function checkSafeBrowsing(url: string): Promise<{ status: 'Bom' | 'Ruim' | 'Atenção'; details: string; }> {
    const SAFE_BROWSING_API_URL = `https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${API_KEY}`;

    try {
        const response = await fetch(SAFE_BROWSING_API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                client: {
                    clientId: 'verificador-sites-confiaveis',
                    clientVersion: '1.0.0',
                },
                threatInfo: {
                    threatTypes: ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"],
                    platformTypes: ["ANY_PLATFORM"],
                    threatEntryTypes: ["URL"],
                    threatEntries: [{ url: url }],
                },
            }),
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => null);
            console.error(`Safe Browsing API error: ${response.status} ${response.statusText}`, errorData);
            return {
                status: 'Atenção',
                details: `Não foi possível verificar com o Google Safe Browsing (Erro: ${response.status}). A análise prosseguirá sem esta verificação específica.`,
            };
        }

        const data = await response.json();

        if (data.matches && data.matches.length > 0) {
            const threats = [...new Set(data.matches.map((match: any) => match.threatType.replace(/_/g, ' ').toLowerCase()))].join(', ');
            return {
                status: 'Ruim',
                details: `Ameaças detectadas pelo Google Safe Browsing: ${threats}. Este site é potencialmente perigoso.`,
            };
        }

        return {
            status: 'Bom',
            details: 'Nenhuma ameaça encontrada pelo Google Safe Browsing. O site é considerado seguro contra ameaças conhecidas.',
        };
    } catch (error) {
        console.error('Failed to call Safe Browsing API:', error);
        return {
            status: 'Atenção',
            details: 'Ocorreu um erro ao conectar com a API do Google Safe Browsing. A análise prosseguirá sem esta verificação.',
        };
    }
}


form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const url = urlInput.value.trim();

    if (!url) {
        displayError('Por favor, insira uma URL.');
        return;
    }

    setLoadingState(true);
    try {
        // First, check with the Safe Browsing API
        const safeBrowsingResult = await checkSafeBrowsing(url);
        
        // Then, generate the full analysis with Gemini, providing the Safe Browsing context
        const prompt = createPrompt(url, safeBrowsingResult);
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                tools: [{ googleSearch: {} }],
            },
        });

        const analysisResult = parseAnalysisResponse(response.text);
        const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
        
        displayResults(analysisResult, groundingChunks);

    } catch (error) {
        console.error('Error during analysis:', error);
        displayError('Ocorreu um erro ao analisar a URL. Verifique o console para mais detalhes.');
    } finally {
        setLoadingState(false);
    }
});

function createPrompt(url: string, safeBrowsingResult: { status: string; details: string; }): string {
    const safeBrowsingJson = JSON.stringify({
        status: safeBrowsingResult.status,
        details: safeBrowsingResult.details
    });
    
    return `
      Aja como um especialista em cibersegurança. Analise a URL "${url}" em detalhes.
      Baseie sua análise nas informações mais recentes da web.

      Para a seção "safe_browsing", use EXATAMENTE os seguintes dados que foram obtidos de uma verificação em tempo real da API Google Safe Browsing:
      ${safeBrowsingJson}

      Para todas as outras seções (https_ssl, whois, content_analysis, reputation), realize sua própria análise aprofundada.

      Forneça sua resposta exclusivamente como um objeto JSON, sem nenhum texto ou formatação adicional (como \`\`\`json).
      O objeto JSON deve ter a seguinte estrutura e tipos de dados:
      {
        "score": number,
        "classification": string,
        "summary": string,
        "safe_browsing": {
          "status": string,
          "details": string
        },
        "https_ssl": {
          "status": string,
          "details": string
        },
        "whois": {
          "status": string,
          "details": string
        },
        "content_analysis": {
          "status": string,
          "details": string
        },
        "reputation": {
          "status": string,
          "details": string
        }
      }

      Regras para o conteúdo:
      - "score": Um score de confiabilidade de 0 (perigoso) a 100 (muito seguro). O resultado do Safe Browsing deve influenciar fortemente o score. Se o status for 'Ruim', o score deve ser muito baixo.
      - "classification": Baseado no score: 'Não Confiável' (0-39), 'Suspeito' (40-59), 'Moderadamente Confiável' (60-79), 'Confiável' (80-100).
      - "summary": Um resumo conciso (1-2 frases) da sua análise geral.
      - Para cada seção de análise ("https_ssl", etc.):
        - "status": Use uma única palavra: 'Bom', 'Atenção', ou 'Ruim'.
        - "details": Forneça uma explicação curta e clara (1-3 frases) dos seus achados para aquela categoria.
      - A seção "safe_browsing" já foi fornecida. Copie-a para o resultado final.
    `;
}


function parseAnalysisResponse(responseText: string): any {
    try {
        // Find the start and end of the JSON object
        const startIndex = responseText.indexOf('{');
        const endIndex = responseText.lastIndexOf('}');
        if (startIndex === -1 || endIndex === -1) {
            throw new Error("JSON object not found in the response.");
        }
        const jsonString = responseText.substring(startIndex, endIndex + 1);
        return JSON.parse(jsonString);
    } catch (e) {
        console.error('Failed to parse JSON response:', responseText);
        throw new Error('A resposta da IA não estava no formato esperado.');
    }
}


function setLoadingState(isLoading: boolean) {
    if (isLoading) {
        analyzeButton.disabled = true;
        analyzeButton.innerHTML = '<div class="loader"></div> Analisando...';
        resultContainer.innerHTML = '';
        resultContainer.classList.add('hidden');
    } else {
        analyzeButton.disabled = false;
        analyzeButton.innerHTML = `Analisar <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="arrow-icon"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>`;
    }
}

function displayError(message: string) {
    resultContainer.classList.remove('hidden');
    resultContainer.innerHTML = `<div class="error-message">${message}</div>`;
}

function displayResults(data: any, sources: any[] = []) {
    resultContainer.classList.remove('hidden');
    resultContainer.innerHTML = `
        <div class="score-summary ${getScoreClass(data.score)}">
            <div class="score-circle">
                <svg viewBox="0 0 36 36" class="circular-chart">
                    <path class="circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"></path>
                    <path class="circle" stroke-dasharray="${data.score}, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"></path>
                </svg>
                <span class="score-text">${data.score}</span>
            </div>
            <div class="score-details">
                <h2>${data.classification}</h2>
                <p>${data.summary}</p>
            </div>
        </div>
        
        <h3>Análise Detalhada</h3>
        <div class="details-grid">
            ${createDetailCard('Navegação Segura', data.safe_browsing)}
            ${createDetailCard('HTTPS/SSL', data.https_ssl)}
            ${createDetailCard('Domínio (WHOIS)', data.whois)}
            ${createDetailCard('Análise de Conteúdo', data.content_analysis)}
            ${createDetailCard('Reputação do Domínio', data.reputation)}
        </div>
        
        ${createSourcesSection(sources)}

        <button id="reset-button">Verificar Outro Site</button>
    `;
    
    document.getElementById('reset-button')?.addEventListener('click', () => {
        resultContainer.classList.add('hidden');
        resultContainer.innerHTML = '';
        urlInput.value = '';
        urlInput.focus();
    });
}

function getIcon(status: string) {
    switch (status.toLowerCase()) {
        case 'bom':
            return '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon-good"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>';
        case 'atenção':
            return '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon-warning"><path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path><line x1="12" x2="12" y1="9" y2="13"></line><line x1="12" x2="12.01" y1="17" y2="17"></line></svg>';
        case 'ruim':
            return '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon-bad"><circle cx="12" cy="12" r="10"></circle><line x1="15" x2="9" y1="9" y2="15"></line><line x1="9" x2="15" y1="9" y2="15"></line></svg>';
        default:
            return '';
    }
}

function createDetailCard(title: string, data: { status: string; details: string; }) {
    const statusClass = `status-${data.status.toLowerCase()}`;
    return `
        <div class="detail-card">
            <div class="card-header">
                ${getIcon(data.status)}
                <h4>${title}</h4>
                <span class="status-badge ${statusClass}">${data.status}</span>
            </div>
            <p>${data.details}</p>
        </div>
    `;
}

function createSourcesSection(sources: any[]): string {
    if (!sources || sources.length === 0) {
        return '';
    }

    const sourceLinks = sources.map((source, index) => {
        if (source.web) {
            return `<li><a href="${source.web.uri}" target="_blank" rel="noopener noreferrer">${source.web.title || `Fonte ${index + 1}`}</a></li>`;
        }
        return '';
    }).join('');

    return `
        <div class="sources-section">
            <h4>Fontes da Análise</h4>
            <ul>${sourceLinks}</ul>
        </div>
    `;
}

function getScoreClass(score: number): string {
    if (score >= 80) return 'score-confiavel';
    if (score >= 60) return 'score-moderado';
    if (score >= 40) return 'score-suspeito';
    return 'score-nao-confiavel';
}

// PWA Service Worker Registration
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js')
      .then(registration => {
        console.log('ServiceWorker registration successful with scope: ', registration.scope);
      })
      .catch(err => {
        console.error('ServiceWorker registration failed: ', err);
      });
  });
}